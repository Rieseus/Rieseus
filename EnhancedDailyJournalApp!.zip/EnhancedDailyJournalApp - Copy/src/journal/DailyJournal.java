package journal;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

public class DailyJournal {

    private JFrame frame;
    private JTextArea textJournalEntry;
    private JTextField textTags;
    private JList<String> listToDo;
    private JTextField textNewToDo;
    private JSpinner dateSpinner;
    private JSpinner toDoDateSpinner;
    private DefaultListModel<String> toDoListModel;
    private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                DailyJournal window = new DailyJournal();
                window.frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public DailyJournal() {
        initialize();
    }

    private void initialize() {
        frame = new JFrame();
        frame.setBounds(100, 100, 800, 600);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());

        JPanel topPanel = new JPanel(new BorderLayout());
        frame.add(topPanel, BorderLayout.NORTH);

        JLabel lblDate = new JLabel("Date:");
        topPanel.add(lblDate, BorderLayout.WEST);

        dateSpinner = new JSpinner(new SpinnerDateModel());
        JSpinner.DateEditor dateEditor = new JSpinner.DateEditor(dateSpinner, "yyyy-MM-dd");
        dateSpinner.setEditor(dateEditor);
        topPanel.add(dateSpinner, BorderLayout.CENTER);

        JPanel centerPanel = new JPanel(new GridLayout(2, 1));
        frame.add(centerPanel, BorderLayout.CENTER);

        JPanel journalPanel = new JPanel(new BorderLayout());
        centerPanel.add(journalPanel);

        JLabel lblJournalEntry = new JLabel("Journal Entry:");
        journalPanel.add(lblJournalEntry, BorderLayout.NORTH);

        textJournalEntry = new JTextArea();
        textJournalEntry.setLineWrap(true);
        textJournalEntry.setWrapStyleWord(true);
        JScrollPane scrollPane = new JScrollPane(textJournalEntry);
        journalPanel.add(scrollPane, BorderLayout.CENTER);

        JPanel tagsPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        journalPanel.add(tagsPanel, BorderLayout.SOUTH);

        JLabel lblTags = new JLabel("Tags:");
        tagsPanel.add(lblTags);

        textTags = new JTextField(20);
        tagsPanel.add(textTags);

        JPanel toDoPanel = new JPanel(new BorderLayout());
        centerPanel.add(toDoPanel);

        JLabel lblToDoList = new JLabel("To-Do List:");
        toDoPanel.add(lblToDoList, BorderLayout.NORTH);

        toDoListModel = new DefaultListModel<>();
        listToDo = new JList<>(toDoListModel);
        listToDo.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane toDoScrollPane = new JScrollPane(listToDo);
        toDoPanel.add(toDoScrollPane, BorderLayout.CENTER);

        JPanel newToDoPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        toDoPanel.add(newToDoPanel, BorderLayout.SOUTH);

        textNewToDo = new JTextField(20);
        newToDoPanel.add(textNewToDo);

        toDoDateSpinner = new JSpinner(new SpinnerDateModel());
        JSpinner.DateEditor toDoDateEditor = new JSpinner.DateEditor(toDoDateSpinner, "yyyy-MM-dd HH:mm");
        toDoDateSpinner.setEditor(toDoDateEditor);
        newToDoPanel.add(toDoDateSpinner);

        JButton btnAddToDo = new JButton("Add To-Do");
        btnAddToDo.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                addNewToDo();
            }
        });
        newToDoPanel.add(btnAddToDo);

        JPanel bottomPanel = new JPanel(new GridLayout(2, 3));
        frame.add(bottomPanel, BorderLayout.SOUTH);

        JButton btnSaveJournal = new JButton("Save Journal Entry");
        btnSaveJournal.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                saveJournalEntry();
            }
        });
        bottomPanel.add(btnSaveJournal);

        JButton btnSaveToDos = new JButton("Save To-Dos");
        btnSaveToDos.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                saveToDos();
            }
        });
        bottomPanel.add(btnSaveToDos);

        JButton btnLoad = new JButton("Load Entry");
        btnLoad.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                loadJournalEntry();
            }
        });
        bottomPanel.add(btnLoad);

        JButton btnViewEntries = new JButton("View All Entries");
        btnViewEntries.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                viewAllEntries();
            }
        });
        bottomPanel.add(btnViewEntries);

        JButton btnDeleteEntry = new JButton("Delete Entry");
        btnDeleteEntry.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                deleteEntry();
            }
        });
        bottomPanel.add(btnDeleteEntry);

        JButton btnDeleteAllEntries = new JButton("Delete All Entries");
        btnDeleteAllEntries.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                deleteAllEntries();
            }
        });
        bottomPanel.add(btnDeleteAllEntries);

        JButton btnDeleteToDo = new JButton("Delete To-Do");
        btnDeleteToDo.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                deleteToDo();
            }
        });
        bottomPanel.add(btnDeleteToDo);

        JButton btnDeleteAllToDos = new JButton("Delete All To-Dos");
        btnDeleteAllToDos.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                deleteAllToDos();
            }
        });
        bottomPanel.add(btnDeleteAllToDos);
    }

    private void saveJournalEntry() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss");
        String timestamp = sdf.format(new Date());
        String entryText = textJournalEntry.getText();
        String tags = textTags.getText();

        try (BufferedWriter writer = new BufferedWriter(new FileWriter("journal_" + timestamp + ".txt"))) {
            writer.write("Date: " + timestamp + "\n");
            writer.write("Entry: " + entryText + "\n");
            writer.write("Tags: " + tags + "\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void saveToDos() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss");
        String timestamp = sdf.format(new Date());
        String[] toDos = new String[toDoListModel.size()];
        toDoListModel.copyInto(toDos);

        try (BufferedWriter writer = new BufferedWriter(new FileWriter("todos_" + timestamp + ".txt"))) {
            writer.write("Date: " + timestamp + "\n");
            writer.write("To-Dos:\n");
            for (String toDo : toDos) {
                writer.write("- " + toDo + "\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void loadJournalEntry() {
        JFrame loadFrame = new JFrame("Load Journal Entry");
        loadFrame.setSize(400, 300);
        loadFrame.setLayout(new BorderLayout());

        DefaultListModel<String> fileListModel = new DefaultListModel<>();
        JList<String> fileList = new JList<>(fileListModel);
        fileList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane fileScrollPane = new JScrollPane(fileList);
        loadFrame.add(fileScrollPane, BorderLayout.CENTER);

        File[] files = new File(".").listFiles((dir, name) -> name.startsWith("journal_") && name.endsWith(".txt"));
        if (files != null) {
            for (File file : files) {
                fileListModel.addElement(file.getName());
            }
        }

        JButton btnLoadSelected = new JButton("Load Selected");
        btnLoadSelected.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String selectedFile = fileList.getSelectedValue();
                if (selectedFile != null) {
                    loadJournalEntryFromFile(selectedFile);
                    loadFrame.dispose();
                }
            }
        });
        loadFrame.add(btnLoadSelected, BorderLayout.SOUTH);

        loadFrame.setVisible(true);
    }

    private void loadJournalEntryFromFile(String fileName) {
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            StringBuilder entryText = new StringBuilder();
            StringBuilder tags = new StringBuilder();

            while ((line = reader.readLine()) != null) {
                if (line.startsWith("Entry: ")) {
                    entryText.append(line.substring(7)).append("\n");
                } else if (line.startsWith("Tags: ")) {
                    tags.append(line.substring(6));
                }
            }

            textJournalEntry.setText(entryText.toString().trim());
            textTags.setText(tags.toString().trim());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void viewAllEntries() {
        JFrame allEntriesFrame = new JFrame("All Journal Entries");
        allEntriesFrame.setSize(800, 600);
        allEntriesFrame.setLayout(new BorderLayout());

        JTextArea allEntriesArea = new JTextArea();
        allEntriesArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(allEntriesArea);
        allEntriesFrame.add(scrollPane, BorderLayout.CENTER);

        File[] journalFiles = new File(".").listFiles((dir, name) -> name.startsWith("journal_") && name.endsWith(".txt"));
        File[] toDoFiles = new File(".").listFiles((dir, name) -> name.startsWith("todos_") && name.endsWith(".txt"));

        if (journalFiles != null) {
            for (File file : journalFiles) {
                try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
                    allEntriesArea.append("File: " + file.getName() + "\n");
                    String line;
                    while ((line = reader.readLine()) != null) {
                        allEntriesArea.append(line + "\n");
                    }
                    allEntriesArea.append("\n-------------------------\n\n");
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        if (toDoFiles != null) {
            for (File file : toDoFiles) {
                try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
                    allEntriesArea.append("File: " + file.getName() + "\n");
                    String line;
                    while ((line = reader.readLine()) != null) {
                        allEntriesArea.append(line + "\n");
                    }
                    allEntriesArea.append("\n-------------------------\n\n");
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        allEntriesFrame.setVisible(true);
    }

    private void deleteEntry() {
        JFrame deleteFrame = new JFrame("Delete Journal Entry");
        deleteFrame.setSize(400, 300);
        deleteFrame.setLayout(new BorderLayout());

        DefaultListModel<String> fileListModel = new DefaultListModel<>();
        JList<String> fileList = new JList<>(fileListModel);
        fileList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane fileScrollPane = new JScrollPane(fileList);
        deleteFrame.add(fileScrollPane, BorderLayout.CENTER);

        File[] files = new File(".").listFiles((dir, name) -> name.startsWith("journal_") && name.endsWith(".txt"));
        if (files != null) {
            for (File file : files) {
                fileListModel.addElement(file.getName());
            }
        }

        JButton btnDeleteSelected = new JButton("Delete Selected");
        btnDeleteSelected.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String selectedFile = fileList.getSelectedValue();
                if (selectedFile != null) {
                    new File(selectedFile).delete();
                    fileListModel.removeElement(selectedFile);
                }
            }
        });
        deleteFrame.add(btnDeleteSelected, BorderLayout.SOUTH);

        deleteFrame.setVisible(true);
    }

    private void deleteAllEntries() {
        File[] files = new File(".").listFiles((dir, name) -> name.startsWith("journal_") && name.endsWith(".txt"));
        if (files != null) {
            for (File file : files) {
                file.delete();
            }
        }
    }

    private void deleteToDo() {
        int selectedIndex = listToDo.getSelectedIndex();
        if (selectedIndex != -1) {
            toDoListModel.remove(selectedIndex);
        }
    }

    private void deleteAllToDos() {
        toDoListModel.clear();
    }

    private void addNewToDo() {
        String newToDo = textNewToDo.getText();
        if (!newToDo.isEmpty()) {
            String toDoDate = sdf.format((Date) toDoDateSpinner.getValue());
            String toDoWithDate = newToDo + " (Due: " + toDoDate + ")";
            toDoListModel.addElement(toDoWithDate);
            textNewToDo.setText("");

            scheduleReminder(toDoDate, newToDo);
        }
    }

    private void scheduleReminder(String reminderDateStr, String reminderText) {
        try {
            Date reminderDate = sdf.parse(reminderDateStr);
            Timer timer = new Timer();
            timer.schedule(new TimerTask() {
                @Override
                public void run() {
                    JOptionPane.showMessageDialog(frame, "Reminder: " + reminderText);
                }
            }, reminderDate);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
