/**
 * 
 */
/**
 * 
 */
module EnhancedDailyJournalApp {
	requires java.desktop;
}